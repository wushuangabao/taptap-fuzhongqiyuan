-- 文明图谱的矢量表现层。只绘制数据，不调用模拟随机数。
local UI = require("urhox-libs/UI")
local W = {}

W.Colors = {
    ink = {35, 56, 45, 255}, muted = {122, 131, 117, 255},
    paper = {246, 245, 235, 255}, card = {255, 254, 247, 255},
    line = {222, 225, 210, 255}, green = {66, 111, 72, 255},
    gold = {185, 143, 61, 255}, teal = {57, 148, 135, 255},
    red = {190, 93, 73, 255}, soil = {166, 149, 113, 255},
}

local function Color(c, alpha)
    return nvgRGBA(math.floor(c[1]), math.floor(c[2]), math.floor(c[3]), math.floor(alpha or c[4] or 255))
end

local function Rect(vg, x, y, w, h, c, radius)
    nvgBeginPath(vg)
    if radius and radius > 0 then
        nvgRoundedRect(vg, x, y, math.max(0, w), math.max(0, h), radius)
    else
        nvgRect(vg, x, y, math.max(0, w), math.max(0, h))
    end
    nvgFillColor(vg, Color(c))
    nvgFill(vg)
end

local function Line(vg, x1, y1, x2, y2, c, width)
    nvgBeginPath(vg)
    nvgMoveTo(vg, x1, y1)
    nvgLineTo(vg, x2, y2)
    nvgStrokeWidth(vg, width or 1)
    nvgStrokeColor(vg, Color(c))
    nvgStroke(vg)
end

local function Circle(vg, x, y, r, c)
    nvgBeginPath(vg)
    nvgCircle(vg, x, y, math.max(0, r))
    nvgFillColor(vg, Color(c))
    nvgFill(vg)
end

local function Outline(vg, x, y, w, h, c, thickness, radius)
    nvgBeginPath(vg)
    nvgRoundedRect(vg, x, y, w, h, radius or 0)
    nvgStrokeColor(vg, Color(c))
    nvgStrokeWidth(vg, thickness or 1)
    nvgStroke(vg)
end

local function Mix(a, b, t)
    t = math.max(0, math.min(1, t))
    return {a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, 255}
end

---@class OriginIcon : Widget
---@field kind string
---@field color table
local Icon = UI.Widget:Extend("OriginIcon")

function Icon:Init(props)
    UI.Widget.Init(self, props)
    self.kind = props.kind or "leaf"
    self.color = props.color or W.Colors.green
end

function Icon:Render(vg)
    local l = self:GetAbsoluteLayout()
    local size = math.min(l.w, l.h)
    local x, y = l.x + l.w / 2, l.y + l.h / 2
    local r = size * 0.35
    local c = self.color
    nvgSave(vg)
    nvgStrokeColor(vg, Color(c))
    nvgStrokeWidth(vg, 1.6)
    if self.kind == "leaf" or self.kind == "agriculture" then
        Line(vg, x, y + r, x, y - r, c, 1.6)
        for k = 1, 3 do
            local py = y + r * 0.4 - k * r * 0.5
            Line(vg, x, py + r * 0.35, x - r * 0.7, py - r * 0.1, c, 2)
            Line(vg, x, py + r * 0.35, x + r * 0.7, py - r * 0.1, c, 2)
        end
    elseif self.kind == "craft" then
        nvgBeginPath(vg)
        nvgMoveTo(vg, x - r, y - r * 0.45)
        nvgLineTo(vg, x + r * 0.4, y - r * 0.45)
        nvgLineTo(vg, x + r, y - r)
        nvgLineTo(vg, x + r, y + r * 0.1)
        nvgLineTo(vg, x + r * 0.2, y + r * 0.5)
        nvgLineTo(vg, x - r * 0.55, y + r * 0.5)
        nvgClosePath(vg)
        nvgStroke(vg)
        Line(vg, x, y + r * 0.5, x, y + r, c, 1.6)
        Line(vg, x - r * 0.6, y + r, x + r * 0.6, y + r, c, 1.6)
    elseif self.kind == "institution" then
        Circle(vg, x, y, r * 0.35, c)
        for k = 1, 8 do
            local a = k * math.pi / 4
            Line(vg, x + math.cos(a) * r * 0.65, y + math.sin(a) * r * 0.65,
                x + math.cos(a) * r, y + math.sin(a) * r, c, 1.5)
        end
    elseif self.kind == "protect" then
        nvgBeginPath(vg)
        nvgMoveTo(vg, x, y - r)
        nvgLineTo(vg, x + r * 0.8, y - r * 0.6)
        nvgLineTo(vg, x + r * 0.65, y + r * 0.4)
        nvgLineTo(vg, x, y + r)
        nvgLineTo(vg, x - r * 0.65, y + r * 0.4)
        nvgLineTo(vg, x - r * 0.8, y - r * 0.6)
        nvgClosePath(vg)
        nvgStroke(vg)
    elseif self.kind == "population" then
        Circle(vg, x, y - r * 0.5, r * 0.35, c)
        nvgBeginPath(vg)
        nvgArc(vg, x, y + r * 0.5, r * 0.7, math.pi, 2 * math.pi, NVG_CW)
        nvgStroke(vg)
        Circle(vg, x - r * 0.85, y - r * 0.1, r * 0.23, c)
        Circle(vg, x + r * 0.85, y - r * 0.1, r * 0.23, c)
    else
        local direction = self.kind == "foodDown" and -1 or 1
        Line(vg, x - r, y + r * direction, x + r, y - r * direction, c, 1.8)
        Line(vg, x + r, y - r * direction, x + r, y, c, 1.8)
        Line(vg, x + r, y - r * direction, x, y - r * direction, c, 1.8)
    end
    nvgRestore(vg)
end
W.Icon = Icon

---@class OriginMap : Widget
---@field ctx table
---@field clock number
---@field bounds table
local Map = UI.Widget:Extend("OriginMap")

function Map:Init(props)
    UI.Widget.Init(self, props)
    self.ctx = props.ctx
    self.clock = 0
    self.bounds = {x = 0, y = 0, cw = 0, ch = 0}
end

function Map:Update(dt)
    if not self.ctx.paused then self.clock = self.clock + dt end
end

function Map:Geometry()
    local l = self:GetAbsoluteLayout()
    local world = self.ctx.world
    local cw = math.max(1, math.min((l.w - 52) / world.config.width, (l.h - 36) / world.config.height * 1.18))
    local ch = cw / 1.18
    local w, h = cw * world.config.width, ch * world.config.height
    return {x = l.x + (l.w - w) / 2, y = l.y + (l.h - h) / 2, cw = cw, ch = ch, w = w, h = h}
end

function Map:Pick(x, y)
    local render = self:GetAbsoluteLayout()
    local visual = self:GetAbsoluteLayoutForHitTest()
    -- 滚动容器通过渲染平移显示地图，点击坐标须回到同一绘图空间。
    local b = self:Geometry()
    local localX, localY = x + render.x - visual.x, y + render.y - visual.y
    local world = self.ctx.world
    local cx, cy = math.floor((localX - b.x) / b.cw) + 1, math.floor((localY - b.y) / b.ch) + 1
    if cx < 1 or cy < 1 or cx > world.config.width or cy > world.config.height then return end
    self.ctx.selectCell(cx, cy)
end

function Map:OnPointerDown(event)
    if event:IsTouch() or event:IsPrimaryButton() then self:Pick(event.x, event.y) end
end

local function House(vg, x, y, size, variant, quality)
    local w, h = size * 0.22, size * 0.21
    Rect(vg, x, y, w, h, {235, 225, 189, 255})
    nvgBeginPath(vg)
    nvgMoveTo(vg, x - 1, y + 1)
    nvgLineTo(vg, x + w / 2, y - h * 0.65)
    nvgLineTo(vg, x + w + 1, y + 1)
    nvgClosePath(vg)
    nvgFillColor(vg, Color(variant == "explore" and {75, 133, 119, 255} or {136, 116, 79, 255}))
    nvgFill(vg)
    Rect(vg, x + w * 0.42, y + h * 0.4, w * 0.2, h * 0.6, {98, 96, 72, 255})
    if quality > 0.7 then
        Rect(vg, x + w * 0.13, y + h * 0.3, math.max(1, w * 0.18), math.max(1, h * 0.25), {255, 232, 141, 255})
    end
end

function Map:Render(vg)
    local ctx, b = self.ctx, self:Geometry()
    local world = ctx.world
    self.bounds = b
    local l = self:GetAbsoluteLayout()
    Rect(vg, l.x, l.y, l.w, l.h, {232, 234, 219, 255}, 10)
    nvgSave(vg)
    nvgIntersectScissor(vg, l.x + 1, l.y + 1, l.w - 2, l.h - 2)
    -- 地图坐标刻度是几何图形，数值标签由周边 UI 负责。
    for x = 0, world.config.width do
        Line(vg, b.x + x * b.cw, b.y - 6, b.x + x * b.cw, b.y - (x % 4 == 0 and 12 or 9), {162, 172, 148, 160}, 1)
    end
    for y = 0, world.config.height do
        Line(vg, b.x - 7, b.y + y * b.ch, b.x - (y % 4 == 0 and 13 or 10), b.y + y * b.ch, {162, 172, 148, 160}, 1)
    end
    Rect(vg, b.x - 4, b.y - 4, b.w + 8, b.h + 8, {173, 186, 153, 255}, 3)
    for i, cell in ipairs(world.cells) do
        local metric = world.metrics[i]
        local x, y = b.x + (cell.x - 1) * b.cw, b.y + (cell.y - 1) * b.ch
        local quality = metric.craftPerCapita / (world.config.prosperousCraftMultiplier * world.baselineCraft)
        local shade = ((i * 29 + world.seed * 7) % 13) / 13
        local fill
        if ctx.layer == "institution" then
            fill = cell.institution == "explore" and Mix({90, 159, 143}, {135, 191, 164}, shade * 0.6)
                or Mix({194, 177, 136}, {210, 194, 152}, shade * 0.6)
        elseif ctx.layer == "population" then
            fill = Mix({226, 229, 202}, {99, 131, 76}, cell.population / 65)
        else
            fill = Mix({151, 167, 122}, {206, 214, 141}, (quality - 0.4) * 1.15 + shade * 0.15)
        end
        Rect(vg, x + 0.6, y + 0.6, b.cw - 1.2, b.ch - 1.2, fill)
        local fieldW = b.cw * (0.22 + cell.foodShare * 0.14)
        Rect(vg, x + b.cw * 0.08, y + b.ch * 0.15, fieldW, b.ch * 0.66,
            Mix({142, 152, 99}, {179, 177, 111}, shade))
        -- 同色田垄合成一个 path，避免高人口后绘制调用挤占 HUD 与浮层预算。
        nvgBeginPath(vg)
        for k = 1, 4 do
            local fy = y + b.ch * (0.2 + k * 0.12)
            nvgMoveTo(vg, x + b.cw * 0.1, fy)
            nvgLineTo(vg, x + b.cw * 0.07 + fieldW, fy)
        end
        nvgStrokeColor(vg, nvgRGBA(215, 206, 143, 115))
        nvgStrokeWidth(vg, 0.7)
        nvgStroke(vg)
        local houses = math.max(1, math.min(3, math.floor(cell.population / 15)))
        for k = 1, houses do
            local hx = x + b.cw * (0.52 + ((k - 1) % 2) * 0.24)
            local hy = y + b.ch * (0.28 + math.floor((k - 1) / 2) * 0.43)
            House(vg, hx, hy, b.cw, cell.institution, quality)
        end
        if cell.institution == "explore" then
            Circle(vg, x + b.cw - 3.4, y + 3.4, math.max(1.2, b.cw * 0.055), {41, 124, 113, 255})
        end
        if metric.foodRatio < 1 then
            local deficit = math.min(1, (1 - metric.foodRatio) * 3)
            Line(vg, x + 2, y + b.ch - 2, x + b.cw * 0.4, y + b.ch - 2,
                {185, 85, 64, 85 + deficit * 155}, 1.6)
        end
        if metric.foodRatio >= 1 and quality >= 1 then
            Circle(vg, x + b.cw * 0.7, y + b.ch * 0.5, b.cw * 0.17, {255, 232, 126, 85})
            Circle(vg, x + b.cw * 0.7, y + b.ch * 0.5, b.cw * 0.06, {255, 237, 169, 255})
        end
        if cell.protectionTicks > 0 then
            Outline(vg, x + 1.4, y + 1.4, b.cw - 2.8, b.ch - 2.8, {232, 198, 98, 230}, 1.4, 1)
        end
    end
    -- 光点沿真实迁移边流动，亮度随流量增加，时钟不进入模拟。
    if world.lastReport and ctx.showMigration then
        for i, flow in ipairs(world.lastReport.flows) do
            local source, target = world.cells[flow.from], world.cells[flow.to]
            local t = (self.clock * ctx.speed * 0.65 + i * 0.173) % 1
            local sx, sy = b.x + (source.x - 0.5) * b.cw, b.y + (source.y - 0.5) * b.ch
            local tx, ty = b.x + (target.x - 0.5) * b.cw, b.y + (target.y - 0.5) * b.ch
            local alpha = math.min(230, 55 + flow.amount * 180)
            Circle(vg, sx + (tx - sx) * t, sy + (ty - sy) * t, math.min(2.4, 0.7 + flow.amount), {255, 254, 218, alpha})
        end
        if ctx.tickAge < 1.0 then
            for _, change in ipairs(world.lastReport.changes) do
                local cell = world.cells[change.index]
                Outline(vg, b.x + (cell.x - 1) * b.cw + 1, b.y + (cell.y - 1) * b.ch + 1,
                    b.cw - 2, b.ch - 2, {243, 229, 145, 200 * (1 - ctx.tickAge)}, 2)
            end
        end
    end
    local sx, sy = b.x + (ctx.regionX - 1) * b.cw, b.y + (ctx.regionY - 1) * b.ch
    local rw, rh = world.config.regionSize * b.cw, world.config.regionSize * b.ch
    Rect(vg, sx, sy, rw, rh, {255, 246, 189, 32}, 2)
    Outline(vg, sx - 1, sy - 1, rw + 2, rh + 2, {255, 254, 231, 255}, 3, 3)
    Outline(vg, sx - 2.5, sy - 2.5, rw + 5, rh + 5, W.Colors.green, 1, 3)
    for _, dx in ipairs({0, rw}) do
        for _, dy in ipairs({0, rh}) do
            Circle(vg, sx + dx, sy + dy, 2.7, W.Colors.green)
        end
    end
    local selected = world.cells[ctx.selectedIndex]
    Outline(vg, b.x + (selected.x - 1) * b.cw + 2, b.y + (selected.y - 1) * b.ch + 2,
        b.cw - 4, b.ch - 4, {253, 255, 235, 225}, 1, 1)
    nvgRestore(vg)
end
W.Map = Map

---@class OriginChart : Widget
---@field ctx table
---@field metric string
---@field color table
local Chart = UI.Widget:Extend("OriginChart")
function Chart:Init(props)
    UI.Widget.Init(self, props)
    self.ctx = props.ctx
    self.metric = props.metric or "craftPerCapita"
    self.color = props.color or W.Colors.green
end

function Chart:Render(vg)
    local l = self:GetAbsoluteLayout()
    local history, baseline = self.ctx.world.history, self.ctx.baseline
    local lo, hi = math.huge, 0
    for _, item in ipairs(history) do
        local point = item.summary or item
        lo = math.min(lo, point[self.metric] or 0)
        hi = math.max(hi, point[self.metric] or 0)
    end
    if baseline then
        for _, item in ipairs(baseline) do
            local point = item.summary or item
            lo = math.min(lo, point[self.metric] or 0)
            hi = math.max(hi, point[self.metric] or 0)
        end
    end
    if self.metric == "prosperousShare" or self.metric == "exploreShare" then lo, hi = 0, 1 end
    if hi - lo < 0.001 then hi = lo + 1 end
    local range = hi - lo
    local px, py, pw, ph = l.x + 2, l.y + 5, l.w - 4, l.h - 10
    for k = 0, 2 do
        Line(vg, px, py + ph * k / 2, px + pw, py + ph * k / 2, {210, 216, 200, 155}, 0.7)
    end
    if self.metric == "prosperousShare" then
        local goalY = py + ph * 0.2
        for x = px, px + pw - 4, 8 do Line(vg, x, goalY, x + 4, goalY, {187, 149, 68, 170}, 0.8) end
    end
    local function Point(index, value)
        return px + ((index - 1) / (self.ctx.world.config.rounds * self.ctx.world.config.generationsPerRound)) * pw,
            py + ph - math.max(0, math.min(1, (value - lo) / range)) * ph
    end
    if baseline then
        nvgBeginPath(vg)
        for i, item in ipairs(baseline) do
            local point = item.summary or item
            local x, y = Point(i, point[self.metric] or 0)
            if i == 1 then nvgMoveTo(vg, x, y) else nvgLineTo(vg, x, y) end
        end
        nvgStrokeColor(vg, nvgRGBA(154, 164, 145, 135))
        nvgStrokeWidth(vg, 1.2)
        nvgStroke(vg)
    end
    if #history > 1 then
        nvgBeginPath(vg)
        for i, item in ipairs(history) do
            local point = item.summary or item
            local x, y = Point(i, point[self.metric] or 0)
            if i == 1 then nvgMoveTo(vg, x, y) else nvgLineTo(vg, x, y) end
        end
        local last = history[#history].summary or history[#history]
        local lx, ly = Point(#history, last[self.metric] or 0)
        nvgLineTo(vg, lx, py + ph)
        nvgLineTo(vg, px, py + ph)
        nvgClosePath(vg)
        nvgFillPaint(vg, nvgLinearGradient(vg, px, py, px, py + ph, Color(self.color, 45), Color(self.color, 2)))
        nvgFill(vg)
        nvgBeginPath(vg)
        for i, item in ipairs(history) do
            local point = item.summary or item
            local x, y = Point(i, point[self.metric] or 0)
            if i == 1 then nvgMoveTo(vg, x, y) else nvgLineTo(vg, x, y) end
        end
        nvgStrokeColor(vg, Color(self.color))
        nvgStrokeWidth(vg, 1.8)
        nvgStroke(vg)
        Circle(vg, lx, ly, 2.7, self.color)
    else
        local point = history[1].summary or history[1]
        local x, y = Point(1, point[self.metric] or 0)
        Circle(vg, x, y, 2.7, self.color)
    end
end
W.Chart = Chart
return W
