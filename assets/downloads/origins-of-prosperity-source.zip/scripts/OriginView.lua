-- 声明式界面：观察、一次干预、五世代推进、真实历史回顾。
local UI = require("urhox-libs/UI")
local Widgets = require("OriginWidgets")
local S = require("OriginSimulation")
local C = Widgets.Colors
local View = {}

local ACTIONS = {
    {key = "agriculture", title = "农艺改良", subtitle = "农业效率 +12%", icon = "agriculture", color = C.green},
    {key = "craft", title = "工艺改良", subtitle = "工艺效率 +15%", icon = "craft", color = C.gold},
    {key = "foodUp", title = "更多务农", subtitle = "农业投入 +10百分点", icon = "foodUp", color = C.green},
    {key = "foodDown", title = "更多制物", subtitle = "农业投入 −10百分点", icon = "foodDown", color = C.gold},
    {key = "institution", title = "制度试验", subtitle = "设立探索型制度", icon = "institution", color = C.teal},
    {key = "protect", title = "保护试验", subtitle = "降低替代概率 · 5世代", icon = "protect", color = C.gold},
}
local ACTION_DESCRIPTIONS = {
    agriculture = "提高本区农业效率。食物增多可能促进人口增长，但不会直接增加生活用品。",
    craft = "提高本区工艺效率。直接增加生活用品，不直接改变自然人口增长率。",
    foodUp = "将劳动转向农业。温饱更有保障，但生活用品产出将减少。",
    foodDown = "将劳动转向制物。生活用品增多，但请留意人均食物是否足够。",
    institution = "工艺每世代增长由0.2%升至1.5%；当前动员系数降至0.75。不赠送技术或财富。",
    protect = "之后完整5次竞争结算，外来制度替代概率乘0.25。不阻止迁移；全局仅3次。",
}

local ACTION_REASONS = {
    unknown_action = "请选择一种行动。",
    region_out_of_bounds = "干预区域必须完整位于地图内。",
    already_won = "本局已达成现代化目标。",
    generation_limit = "已到达100世代上限。",
    round_limit = "20轮干预机会已用完。",
    round_in_progress = "本轮仍在演进，不能追加行动。",
    no_protection_uses = "3次保护机会已经用完。",
    no_change = "区域内所有格子已达到该行动的上限。",
    non_finite_result = "此操作会超出模型有效数值范围。",
}

local function Label(text, size, color, props)
    props = props or {}
    props.text = text
    props.fontSize = size or 10.5
    props.fontColor = color or C.ink
    props.fontFamily = "sans"
    props.flexShrink = props.flexShrink or 1
    return UI.Label(props)
end

local function Button(text, onClick, props)
    props = props or {}
    props.text = text
    props.onClick = onClick
    props.height = props.height or 36
    props.fontSize = props.fontSize or 10
    props.borderRadius = props.borderRadius or 7
    props.backgroundColor = props.backgroundColor or {239, 241, 230, 255}
    props.hoverBackgroundColor = props.hoverBackgroundColor or {229, 235, 216, 255}
    props.pressedBackgroundColor = props.pressedBackgroundColor or {216, 228, 201, 255}
    props.textColor = props.textColor or C.green
    props.borderWidth = 1
    props.borderColor = props.borderColor or C.line
    props.boxShadow = false
    props.paddingHorizontal = props.paddingHorizontal or 12
    return UI.Button(props)
end

local function Primary(text, onClick, props)
    props = props or {}
    props.backgroundColor = C.green
    props.hoverBackgroundColor = {78, 126, 82, 255}
    props.pressedBackgroundColor = {50, 89, 58, 255}
    props.textColor = {255, 254, 241, 255}
    props.borderColor = C.green
    return Button(text, onClick, props)
end

local function Card(props)
    props.backgroundColor = props.backgroundColor or C.card
    props.borderRadius = 12
    props.borderWidth = 1
    props.borderColor = C.line
    return UI.Panel(props)
end

local function SetLabel(ctx, id, text, color)
    local label = ctx.root:FindById(id) --[[@as Label?]]
    if label then
        label:SetText(text)
        if color then label:SetFontColor(color) end
    end
end

local function SetButton(ctx, id, text, disabled)
    local button = ctx.root:FindById(id) --[[@as Button?]]
    if button then
        if text then button:SetText(text) end
        if disabled ~= nil then button:SetDisabled(disabled) end
    end
end

function View.InitTheme()
    local base = UI.Theme.GetRegisteredTheme("default-taptap") or UI.Theme.defaultTheme
    local theme = UI.Theme.ExtendTheme(base, {
        fonts = {{family = "sans", weights = {normal = "Fonts/MiSans-Regular.ttf", bold = "Fonts/MiSans-Regular.ttf"}}},
        colors = {
            primary = C.green, primaryHover = {83, 129, 87, 255}, primaryPressed = {48, 90, 59, 255},
            background = C.paper, surface = C.card, surfaceHover = {241, 243, 232, 255},
            text = C.ink, textSecondary = C.muted, border = C.line,
            disabled = {228, 231, 220, 255}, disabledText = {150, 156, 144, 255},
            success = C.green, warning = C.gold, error = C.red,
        },
        components = {Label = {fontSize = 10.5}, Button = {height = 36, fontSize = 10, borderRadius = 7, boxShadow = false}},
    })
    UI.Init({theme = theme, scale = UI.Scale.DEFAULT})
end

local function Stat(id, name, value, icon, color)
    return UI.Row {
        gap = 10, alignItems = "center", flexShrink = 1,
        children = {
            Widgets.Icon {kind = icon, color = color, width = 28, height = 28, pointerEvents = "none"},
            UI.Column {gap = 2, children = {
                Label(name, 8, C.muted),
                Label(value, 16, C.ink, {id = id, height = 25}),
            }},
        }
    }
end

local function Header(ctx)
    return UI.Row {
        id = "header", height = 76, gap = 22, alignItems = "center", justifyContent = "space-between",
        paddingHorizontal = 4,
        children = {
            UI.Row {gap = 12, alignItems = "center", children = {
                Card {width = 45, height = 45, backgroundColor = {227, 234, 213, 255}, alignItems = "center", justifyContent = "center",
                    children = {Widgets.Icon {kind = "leaf", width = 34, height = 34}}},
                UI.Column {gap = 1, children = {
                    Label("富种起源", 23, C.ink, {letterSpacing = 4}),
                    Label("ORIGINS OF PROSPERITY  /  涌现策略模拟", 7.4, C.muted, {letterSpacing = 1}),
                }},
            }},
            UI.Row {id = "headerStats", gap = 27, alignItems = "center", children = {
                Stat("worldPopulation", "世界人口", "—", "population", C.green),
                Stat("worldCraft", "人均生活用品", "—", "craft", C.gold),
                Stat("worldProsperity", "繁荣人口占比", "0.0%", "institution", C.teal),
            }},
            UI.Row {gap = 8, children = {
                Button("玩法说明", function() View.Help(ctx) end, {width = 85}),
                Button("同种子重开", function() View.RestartDialog(ctx) end, {width = 97}),
            }},
        }
    }
end

local function MapToolbar(ctx)
    local buttons = {}
    for _, layer in ipairs({{"quality", "生活品质"}, {"population", "人口密度"}, {"institution", "制度分布"}}) do
        local key = layer[1]
        buttons[#buttons + 1] = Button(layer[2], function()
            ctx.layer = key
            View.Refresh(ctx)
        end, {id = "layer_" .. key, height = 30, width = 81, fontSize = 9})
    end
    return UI.Row {height = 43, alignItems = "center", justifyContent = "space-between", gap = 6, children = {
        UI.Row {alignItems = "center", gap = 8, children = {
            Label("文明图谱", 12.5, C.ink, {letterSpacing = 1}),
            Label("24 × 16", 8, C.muted),
        }},
        UI.Row {gap = 4, children = buttons},
    }}
end

local function MapLegend(ctx)
    return UI.Row {height = 32, alignItems = "center", justifyContent = "space-between", gap = 6, children = {
        Label("亮度：生活品质   红线：缺粮   青点：探索型", 8.3, C.muted, {id = "mapLegend"}),
        Button("迁移光点：开", function()
            ctx.showMigration = not ctx.showMigration
            View.Refresh(ctx)
        end, {id = "migrationToggle", height = 24, width = 98, fontSize = 8.3, backgroundColor = C.card}),
    }}
end

local function TimelineCard(ctx, metric, title, id, color, value)
    return UI.Column {flexGrow = 1, flexBasis = 0, minWidth = 0, gap = 3, children = {
        UI.Row {alignItems = "center", justifyContent = "space-between", gap = 4, children = {
            Label(title, 8, C.muted),
            Label(value or "—", 10, color, {id = id}),
        }},
        Widgets.Chart {ctx = ctx, metric = metric, color = color, height = 53, width = "100%", pointerEvents = "none"},
    }}
end

local function TrendPanel(ctx)
    return Card {height = 110, padding = {10, 14}, gap = 5, children = {
        UI.Row {justifyContent = "space-between", children = {
            Label("世界的长期变化", 9, C.ink),
            Label("实线：本局  ·  灰线：无干预基线", 7.5, C.muted),
        }},
        UI.Row {gap = 17, children = {
            TimelineCard(ctx, "population", "世界人口", "trendPopulation", C.green),
            TimelineCard(ctx, "craftPerCapita", "人均生活用品", "trendCraft", C.gold),
            TimelineCard(ctx, "exploreShare", "探索型人口", "trendExplore", C.teal),
        }},
    }}
end

local function LeftPanel(ctx)
    return UI.Column {id = "leftPanel", flexGrow = 1, flexBasis = 0, minWidth = 0, gap = 8, children = {
        Card {flexGrow = 1, flexBasis = 0, minHeight = 200, padding = {4, 14, 0, 14}, children = {
            MapToolbar(ctx),
            Widgets.Map {id = "worldMap", ctx = ctx, flexGrow = 1, flexBasis = 0, width = "100%", minHeight = 130},
            MapLegend(ctx),
        }},
        Card {height = 49, padding = {7, 13}, gap = 2, backgroundColor = {239, 242, 228, 255}, children = {
            Label("文明从一小片土地开始。点击地图，领导一个3 × 3区域。", 9.5, C.green, {id = "eventTitle", maxLines = 1}),
            Label("第一轮可比较农业与工艺：人口更多，不一定意味着生活更好。", 8.3, C.muted, {id = "eventDetail", maxLines = 1}),
        }},
        TrendPanel(ctx),
    }}
end

local function DataRow(name, id)
    return UI.Row {height = 24, justifyContent = "space-between", alignItems = "center", children = {
        Label(name, 9, C.muted), Label("—", 10, C.ink, {id = id}),
    }}
end

local function Inspector(ctx)
    return Card {padding = {12, 14}, gap = 3, children = {
        UI.Row {justifyContent = "space-between", children = {
            Label("地块观察", 11.5, C.ink),
            Label("(12, 8)", 9, C.green, {id = "cellPosition"}),
        }},
        DataRow("人口规模", "cellPopulation"),
        DataRow("温饱比 · 1为温饱", "cellFood"),
        DataRow("人均生活用品", "cellCraft"),
        DataRow("农业投入比例", "cellShare"),
        DataRow("制度 / 保护", "cellInstitution"),
        DataRow("当前竞争力", "cellPower"),
        Label("农业效率  —    工艺效率  —", 8, C.muted, {id = "cellTech", marginTop = 3}),
        UI.Divider {color = C.line, spacing = 3},
        Label("人口变化将在世代推进后记录", 8.2, C.muted, {id = "cellDelta", whiteSpace = "normal", maxLines = 2}),
        Label("文化变化：—", 8, C.muted, {id = "cellCulture", whiteSpace = "normal", maxLines = 2}),
    }}
end

local function ActionCard(ctx, action)
    return Button(nil, function()
        if ctx.phase ~= "decision" then return end
        ctx.action = ctx.action == action.key and "" or action.key
        View.Refresh(ctx)
    end, {id = "action_" .. action.key, height = 64, paddingHorizontal = 6,
        backgroundColor = C.card, hoverBackgroundColor = {239, 244, 230, 255},
        disabledBackgroundColor = {233, 235, 225, 255},
        flexDirection = "row", alignItems = "center", gap = 5,
        children = {
            Widgets.Icon {width = 23, height = 26, kind = action.icon, color = action.color, pointerEvents = "none"},
            UI.Column {flexGrow = 1, flexBasis = 0, gap = 2, pointerEvents = "none", children = {
                Label(action.title, 9.2, C.ink, {id = "actionTitle_" .. action.key}),
                Label(action.subtitle, 7.2, C.muted, {id = "actionSubtitle_" .. action.key, whiteSpace = "normal", maxLines = 2}),
            }},
        },
    })
end

local function ActionsPanel(ctx)
    ---@type Widget[]
    local children = {
        UI.Row {justifyContent = "space-between", children = {
            Label("本轮干预", 11.5, C.ink),
            Label("每轮一次", 8.5, C.muted),
        }},
        Label("影响9格 · 区域(11, 7)—(13, 9)", 8.2, C.green, {id = "regionDescription"}),
    }
    local grid = UI.SimpleGrid {columns = 2, gap = 6, width = "100%"}
    for _, action in ipairs(ACTIONS) do grid:AddChild(ActionCard(ctx, action)) end
    children[#children + 1] = grid
    return Card {padding = {13, 14}, gap = 7, children = children}
end

local function ProgressPanel(ctx)
    return Card {padding = {12, 14}, gap = 6, backgroundColor = {232, 238, 220, 255}, children = {
        UI.Row {justifyContent = "space-between", children = {
            Label("走向全面现代化", 10, C.green),
            Label("0 / 5世代", 8, C.green, {id = "winStreak"}),
        }},
        UI.ProgressBar {id = "prosperityProgress", value = 0, max = 1, height = 6,
            fillColor = C.green, backgroundColor = {210, 220, 195, 255}, borderWidth = 0, showLabel = false},
        Label("80%人口温饱，且生活用品达到开局2倍。", 8, C.green, {whiteSpace = "normal", maxLines = 2}),
        Label("持续5世代 · 以人口加权，非格子数", 7.5, C.muted),
    }}
end

local function RightPanel(ctx)
    return UI.Column {id = "rightPanel", width = 302, height = "100%", flexShrink = 0, gap = 9,
        children = {
            UI.ScrollView {width = "100%", flexGrow = 1, flexBasis = 0, showScrollbar = true,
                scrollY = true, scrollX = false, children = {
                    UI.Column {width = "100%", gap = 9, paddingRight = 3, children = {
                        Inspector(ctx), ActionsPanel(ctx), ProgressPanel(ctx),
                    }},
                },
            },
            Card {padding = {10, 12}, gap = 6, children = {
                Label("选择一种行动，查看直接影响后再确认。", 8.5, C.muted,
                    {id = "actionDescription", whiteSpace = "normal", maxLines = 3, minHeight = 37}),
                Primary("选择行动后推进", function() View.Confirm(ctx) end,
                    {id = "confirm", width = "100%", height = 41, fontSize = 11.2, disabled = true}),
                Label("确认后推进5世代（100年），不可撤销。", 7.1, C.muted, {textAlign = "center"}),
            }},
        },
    }
end

local function ControlBar(ctx)
    return UI.Row {id = "controls", height = 44, gap = 10, alignItems = "center", justifyContent = "space-between",
        children = {
            UI.Row {gap = 10, alignItems = "center", children = {
                Label("第 01 / 20 轮", 11, C.ink, {id = "roundLabel"}),
                Label("世代 000 / 100", 9, C.muted, {id = "generationLabel"}),
                Label("决策期", 8.5, C.green, {id = "phaseLabel"}),
            }},
            UI.Row {gap = 7, alignItems = "center", children = {
                Label("保护 3 / 3", 9, C.gold, {id = "protectLeft"}),
                Button("暂停 / 播放", function()
                    if ctx.phase == "simulation" then ctx.paused = not ctx.paused end
                    View.Refresh(ctx)
                end, {id = "play", width = 92, height = 29, fontSize = 9}),
                Button("1×速度", function()
                    ctx.speed = ctx.speed == 1 and 2 or (ctx.speed == 2 and 4 or 1)
                    View.Refresh(ctx)
                end, {id = "speed", width = 72, height = 29, fontSize = 9}),
            }},
        },
    }
end

function View.Build(ctx)
    local root = UI.Panel {width = "100%", height = "100%", backgroundColor = C.paper,
        children = {
            UI.SafeAreaView {id = "safe", width = "100%", height = "100%", nativeMenuInset = true,
                paddingHorizontal = 22, paddingBottom = 10, gap = 2, children = {
                    Header(ctx),
                    UI.Divider {color = C.line, spacing = 0},
                    ControlBar(ctx),
                    UI.ScrollView {id = "mainScroll", flexGrow = 1, flexBasis = 0, minHeight = 0,
                        scrollY = true, scrollX = false, showScrollbar = false, children = {
                            UI.Row {id = "body", width = "100%", minHeight = 0, gap = 14, children = {
                                LeftPanel(ctx), RightPanel(ctx),
                            }},
                        },
                    },
                    UI.Row {height = 22, alignItems = "center", justifyContent = "space-between", children = {
                        Label("局部干预，观察涌现。没有预定的历史终点。", 7.5, C.muted),
                        Label("种子 " .. tostring(ctx.seed) .. "  ·  规则 v0.1", 7.5, C.muted, {id = "seedLabel"}),
                    }},
                },
            },
        },
    }
    ctx.root = root
    UI.SetRoot(root, true)
    View.Resize(ctx)
    View.Refresh(ctx)
end

function View.Resize(ctx)
    local w, h = UI.GetViewportSize()
    if ctx.viewportW == w and ctx.viewportH == h then return end
    ctx.viewportW, ctx.viewportH = w, h
    local stats = ctx.root:FindById("headerStats")
    local body = ctx.root:FindById("body")
    local right = ctx.root:FindById("rightPanel")
    local left = ctx.root:FindById("leftPanel")
    local safe = ctx.root:FindById("safe")
    local header = ctx.root:FindById("header")
    if not (stats and body and right and left and safe and header) then return end
    stats:SetVisible(w >= 1080)
    safe:SetStyle({paddingHorizontal = w < 800 and 10 or 22})
    header:SetStyle({height = w < 800 and 66 or 76})
    if w < 720 then
        body:SetStyle({flexDirection = "column", height = math.max(790, h - 170)})
        left:SetStyle({flexGrow = 0, flexBasis = "auto", height = 430, minHeight = 390})
        right:SetStyle({width = "100%", height = 350, flexShrink = 0})
    else
        body:SetStyle({flexDirection = "row", height = math.max(380, h - 170)})
        left:SetStyle({flexGrow = 1, flexBasis = 0, height = "100%", minHeight = 0})
        right:SetStyle({width = w < 1020 and 265 or 302, height = "100%", flexShrink = 0})
    end
end

function View.Refresh(ctx)
    if not ctx.root then return end
    local world = ctx.world
    local stats = S.Statistics(world)
    SetLabel(ctx, "worldPopulation", string.format("%.0f", stats.population))
    SetLabel(ctx, "worldCraft", string.format("%.3f", stats.craftPerCapita))
    SetLabel(ctx, "worldProsperity", string.format("%.1f%%", stats.prosperousShare * 100))
    SetLabel(ctx, "trendPopulation", string.format("%.0f", stats.population))
    SetLabel(ctx, "trendCraft", string.format("%.3f", stats.craftPerCapita))
    SetLabel(ctx, "trendExplore", string.format("%.1f%%", stats.exploreShare * 100))
    local displayRound = math.min(world.config.rounds, world.round + (ctx.phase == "decision" and 1 or 0))
    SetLabel(ctx, "roundLabel", string.format("第 %02d / %02d 轮", displayRound, world.config.rounds))
    SetLabel(ctx, "generationLabel", string.format("世代 %03d / %03d", world.generation, world.config.rounds * world.config.generationsPerRound))
    SetLabel(ctx, "phaseLabel", ctx.phase == "decision" and "决策期" or (ctx.phase == "ended" and "历史回顾" or (ctx.paused and "观察中 · 已暂停" or "世代演进中")))
    SetLabel(ctx, "protectLeft", string.format("保护 %d / %d", world.protectionLeft, world.config.protectionUses))
    SetLabel(ctx, "winStreak", string.format("%d / 5世代", world.prosperousStreak))
    local progress = ctx.root:FindById("prosperityProgress") --[[@as ProgressBar?]]
    if progress then progress:SetValue(stats.prosperousShare) end
    SetButton(ctx, "play", ctx.phase == "simulation" and (ctx.paused and "继续播放" or "暂停观察") or "等待干预", ctx.phase ~= "simulation")
    SetButton(ctx, "speed", tostring(ctx.speed) .. "×速度")
    SetButton(ctx, "migrationToggle", "迁移光点：" .. (ctx.showMigration and "开" or "关"))
    local legends = {
        quality = "亮度：生活品质   红线：缺粮   青点：探索型",
        population = "颜色越深人口越多 · 房屋仅作密度示意",
        institution = "青绿：探索型   沙金：动员型   金边：保护",
    }
    SetLabel(ctx, "mapLegend", legends[ctx.layer])
    for _, key in ipairs({"quality", "population", "institution"}) do
        local button = ctx.root:FindById("layer_" .. key)
        if button then button:SetStyle({backgroundColor = ctx.layer == key and {221, 232, 207, 255} or C.card,
            borderColor = ctx.layer == key and {150, 176, 129, 255} or C.line}) end
    end
    local cell, metric = world.cells[ctx.selectedIndex], world.metrics[ctx.selectedIndex]
    SetLabel(ctx, "cellPosition", string.format("(%02d, %02d)", cell.x, cell.y))
    SetLabel(ctx, "cellPopulation", string.format("%.2f", cell.population))
    SetLabel(ctx, "cellFood", string.format("%.3f %s", metric.foodRatio, metric.foodRatio >= 1 and "温饱" or "缺粮"), metric.foodRatio >= 1 and C.green or C.red)
    SetLabel(ctx, "cellCraft", string.format("%.3f / 目标 %.3f", metric.craftPerCapita, world.baselineCraft * 2))
    SetLabel(ctx, "cellShare", string.format("%.1f%%", cell.foodShare * 100))
    SetLabel(ctx, "cellInstitution", (cell.institution == "explore" and "探索型" or "动员型") ..
        (cell.protectionTicks > 0 and string.format(" · 保护%d", cell.protectionTicks) or ""), cell.institution == "explore" and C.teal or C.soil)
    SetLabel(ctx, "cellPower", string.format("%.2f", metric.power))
    SetLabel(ctx, "cellTech", string.format("农业效率 %.3f    工艺效率 %.3f", cell.agriculture, cell.craft))
    SetLabel(ctx, "regionDescription", string.format("影响9格 · 区域(%d,%d)—(%d,%d)", ctx.regionX, ctx.regionY, ctx.regionX + 2, ctx.regionY + 2))
    if world.lastReport then
        local delta = world.lastReport.deltas[ctx.selectedIndex]
        if delta then
            SetLabel(ctx, "cellDelta", string.format("人口 %.2f → %.2f  /  自然 %+.2f  /  迁入 +%.2f  /  迁出 −%.2f",
                delta.before.population, delta.after.population, delta.natural, delta.incoming, delta.outgoing))
            SetLabel(ctx, "cellCulture", string.format("文化 %+.2f个百分点 · 制度 %+.2f个百分点", (delta.cultureChange or 0) * 100, (delta.institutionFoodChange or 0) * 100))
        end
    else
        SetLabel(ctx, "cellDelta", "人口变化将在世代推进后记录")
        SetLabel(ctx, "cellCulture", "迁移文化与制度变化分阶段同步结算")
    end
    for _, action in ipairs(ACTIONS) do
        local valid = S.ValidateAction(world, action.key, ctx.regionX, ctx.regionY)
        local disabled = ctx.phase ~= "decision" or not valid
        SetButton(ctx, "action_" .. action.key, nil, disabled)
        local button = ctx.root:FindById("action_" .. action.key)
        if button then button:SetStyle({backgroundColor = not disabled and ctx.action == action.key and {231, 239, 217, 255} or C.card,
            borderColor = not disabled and ctx.action == action.key and C.green or C.line}) end
        SetLabel(ctx, "actionTitle_" .. action.key, action.title, disabled and {157, 163, 151, 255} or C.ink)
        SetLabel(ctx, "actionSubtitle_" .. action.key, action.subtitle, disabled and {170, 175, 164, 255} or C.muted)
    end
    local valid, reason = S.ValidateAction(world, ctx.action, ctx.regionX, ctx.regionY)
    local desc = ACTION_DESCRIPTIONS[ctx.action] or "选择一种行动，查看直接影响后再确认。"
    if ctx.phase == "simulation" then desc = "演进期间可暂停、检查地块、切换图层；不能追加干预。"
    elseif ctx.phase == "ended" then desc = "本局已经结束。可继续检查地图，或同种子重开对比。"
    elseif ctx.action ~= "" and not valid then desc = ACTION_REASONS[reason] or reason end
    SetLabel(ctx, "actionDescription", desc)
    local actionName = "选择一种行动"
    for _, action in ipairs(ACTIONS) do if action.key == ctx.action then actionName = action.title end end
    SetButton(ctx, "confirm", ctx.phase == "simulation" and string.format("演进中 · 还剩%d世代", ctx.ticksRemaining) or
        (ctx.phase == "ended" and "查看结算" or (ctx.action == "" and "选择行动后推进" or "确认" .. actionName .. " · 推进100年")),
        ctx.phase ~= "ended" and (ctx.phase ~= "decision" or not valid))
end

function View.Confirm(ctx)
    if ctx.phase == "ended" then View.Ending(ctx); return end
    if ctx.phase ~= "decision" then return end
    local ok, reason = S.ApplyAction(ctx.world, ctx.action, ctx.regionX, ctx.regionY)
    if not ok then UI.Toast.Show(ACTION_REASONS[reason] or reason, {duration = 3}); return end
    ctx.phase = "simulation"
    ctx.paused = false
    ctx.ticksRemaining = ctx.world.config.generationsPerRound
    ctx.accumulator = 0
    ctx.roundStart = ctx.world.generation
    ctx.roundRegion = {x = ctx.regionX, y = ctx.regionY}
    SetLabel(ctx, "eventTitle", "干预已经确认，文明正在回应。")
    SetLabel(ctx, "eventDetail", ACTION_DESCRIPTIONS[ctx.action])
    print(string.format("[行动] 第%d轮 %s 区域(%d,%d) 世代%d", ctx.world.round, ctx.action, ctx.regionX, ctx.regionY, ctx.world.generation))
    View.Refresh(ctx)
end

function View.RoundReport(ctx)
    local world = ctx.world
    local history = world.history
    local previous = history[math.max(1, ctx.roundStart + 1)]
    previous = previous.summary or previous
    local current = S.Statistics(world)
    SetLabel(ctx, "eventTitle", string.format("这100年：人口 %+.0f，生活用品 %+.1f%%。", current.population - previous.population,
        100 * (current.craftPerCapita / previous.craftPerCapita - 1)))
    local migrated, replaced = 0, 0
    for i = ctx.roundStart + 2, #history do
        local report = history[i]
        for _, flow in ipairs(report.flows or {}) do migrated = migrated + flow.amount end
        replaced = replaced + #(report.changes or {})
    end
    SetLabel(ctx, "eventDetail", string.format("迁移流量合计 %.1f人口单位 · 制度替代 %d次 · 探索型人口 %.1f%%", migrated, replaced, current.exploreShare * 100))
    if not ctx.tipsClosed then
        if not ctx.seenMigration and migrated > current.population * 0.008 then
            ctx.seenMigration = true
            UI.Toast.Show("居民向生活更好的邻格迁移，也会改变拥挤程度与生产习惯。", {duration = 6})
        elseif not ctx.seenCompetition and replaced > 0 then
            ctx.seenCompetition = true
            UI.Toast.Show("制度依邻格实际竞争力传播，不按多数投票，也不会删除技术。", {duration = 6})
        elseif not ctx.seenProsperity and current.prosperousShare > 0.02 then
            ctx.seenProsperity = true
            UI.Toast.Show("繁荣开始出现：同时温饱，且生活用品达到开局世界均值的2倍。", {duration = 6})
        end
    end
    ctx.action = ""
    View.Refresh(ctx)
end

local function Modal(ctx, title, width)
    ctx.modalOpen = true
    local viewW, viewH = UI.GetViewportSize()
    local size = viewW < 720 and "fullscreen" or ((width or 650) > 700 and viewW >= 880 and "xl" or ((width or 650) < 500 and "md" or "lg"))
    local modal = UI.Modal {title = title, size = size,
        closeOnOverlay = false, closeOnEscape = true, showCloseButton = true,
        backgroundColor = C.card, titleTextColor = C.ink, closeIconColor = C.green,
        titleFontSize = 12, contentGap = 7, contentPadding = {12, 18, 12, 18},
        onClose = function(self) ctx.modalOpen = false; self:Destroy() end,
    }
    local bodyHeight = (width or 650) < 500 and 115 or ((width or 650) > 700 and 350 or 425)
    local body = UI.ScrollView {width = "100%", height = math.max(160, math.min(bodyHeight, viewH - 175)),
        scrollY = true, scrollX = false, showScrollbar = true, gap = 7}
    modal:AddContent(body)
    return modal, body
end

function View.Help(ctx)
    if ctx.modalOpen then return end
    local modal, body = Modal(ctx, "一部没有预设结局的文明史", 660)
    local poem = {"是给文明以岁月，", "还是给岁月以文明？", "我们免于此虑，", "只因活在例外的时代。", "这个时代，", "靠什么开启，会不会结束？"}
    local lines = {}
    for _, text in ipairs(poem) do lines[#lines + 1] = Label(text, 12, C.green, {textAlign = "center"}) end
    body:AddChild(UI.Column {width = "100%", gap = 3, children = lines})
    body:AddChild(UI.Divider {color = C.line, spacing = 6})
    for _, text in ipairs({
        "1. 点击地图，选择一个完整3 × 3区域；可随时取消行动选择。",
        "2. 每轮只确认一次干预，自动推进5世代（100年）。",
        "3. 演进中可暂停检查、切换图层；不额外获得行动。",
        "4. 食物支持人口，生活用品提高福利；迁移与制度都按邻格结算。",
        "5. 繁荣人口达到80%并持续5世代即获胜，最多20轮。",
    }) do body:AddChild(Label(text, 9.5, C.ink, {whiteSpace = "normal", maxLines = 2})) end
    body:AddChild(UI.Checkbox {label = "关闭后续因果提示", checked = ctx.tipsClosed,
        onChange = function(_, checked) ctx.tipsClosed = checked end})
    body:AddChild(Label("受吴乐旻《富种起源》及相关理论研究启发的策略模拟。规则经过游戏化简化。", 8, C.muted,
        {whiteSpace = "normal", maxLines = 2}))
    modal:SetFooter(UI.Row {justifyContent = "flex-end", children = {
        Primary("从这里开启文明", function() modal:Close() end, {width = 172}),
    }})
    modal:Open()
end

function View.RestartDialog(ctx)
    if ctx.modalOpen then return end
    local modal, body = Modal(ctx, "重新开始同一种子？", 460)
    body:AddChild(Label("当前进度会被清空。地形、初始制度与随机序列保持相同，可比较另一种干预路线。", 10.5, C.ink,
        {whiteSpace = "normal", maxLines = 3}))
    modal:SetFooter(UI.Row {justifyContent = "flex-end", gap = 9, children = {
        Button("保留本局", function() modal:Close() end, {width = 100}),
        Primary("同种子重开", function() modal:Close(); ctx.restart() end, {width = 116}),
    }})
    modal:Open()
end

function View.Ending(ctx)
    if ctx.modalOpen then return end
    local world = ctx.world
    local stats = S.Statistics(world)
    local modal, body = Modal(ctx, world.won and "灯火相连 · 现代化达成" or "百代之后 · 文明仍在路上", 760)
    body:AddChild(Label(world.won and "80%的居民持续5世代生活在繁荣地区。" or "100个世代已经结束。未达通关门槛，不代表没有进步。", 13, C.green,
        {whiteSpace = "normal", maxLines = 2}))
    body:AddChild(Label(string.format("最高繁荣 %.1f%%   /   当前人均生活用品 %.3f   /   探索型人口 %.1f%%",
        world.maxProsperousShare * 100, stats.craftPerCapita, stats.exploreShare * 100), 10, C.ink,
        {whiteSpace = "normal", maxLines = 2}))
    body:AddChild(UI.Row {width = "100%", gap = 18, children = {
        TimelineCard(ctx, "prosperousShare", "繁荣人口占比", "endingProsperity", C.green, string.format("%.1f%%", stats.prosperousShare * 100)),
        TimelineCard(ctx, "craftPerCapita", "人均生活用品", "endingCraft", C.gold, string.format("%.3f", stats.craftPerCapita)),
        TimelineCard(ctx, "exploreShare", "探索型人口占比", "endingExplore", C.teal, string.format("%.1f%%", stats.exploreShare * 100)),
    }})
    local firstMigration, firstChange, bestPoint
    for i, item in ipairs(world.history) do
        local point = item.summary or item
        if not firstMigration and #(item.flows or {}) > 0 then firstMigration = i - 1 end
        if not firstChange and #(item.changes or {}) > 0 then firstChange = i - 1 end
        if not bestPoint or point.prosperousShare > bestPoint.share then
            bestPoint = {generation = i - 1, share = point.prosperousShare}
        end
    end
    body:AddChild(Label("从真实记录回望", 11, C.green))
    if firstMigration then body:AddChild(Label(string.format("世代 %d：首次人口迁移。个体追求更好生活，反过来改变地区条件。", firstMigration), 9.5, C.ink,
        {whiteSpace = "normal", maxLines = 2})) end
    if firstChange then body:AddChild(Label(string.format("世代 %d：首次制度替代。传播由竞争力决定，而不是制度的名字。", firstChange), 9.5, C.ink,
        {whiteSpace = "normal", maxLines = 2})) end
    if bestPoint then body:AddChild(Label(string.format("世代 %d：繁荣人口占比达到本局最高 %.1f%%。", bestPoint.generation, bestPoint.share * 100), 9.5, C.ink)) end
    local base = ctx.baseline[#ctx.baseline]
    base = base.summary or base
    body:AddChild(Label(string.format("同种子无干预基线：世代100，人均生活用品 %.3f，探索型人口 %.1f%%。", base.craftPerCapita, base.exploreShare * 100), 9, C.muted,
        {whiteSpace = "normal", maxLines = 2}))
    body:AddChild(Label("参数保持设计文档v0.1原值，通关难度尚未校准。模拟没有保证任何制度成功。", 8.5, C.muted,
        {whiteSpace = "normal", maxLines = 2}))
    modal:SetFooter(UI.Row {justifyContent = "flex-end", gap = 9, children = {
        Button("继续检查地图", function() modal:Close() end, {width = 127}),
        Primary("同种子再试一次", function() modal:Close(); ctx.restart() end, {width = 144}),
    }})
    modal:Open()
end
return View
