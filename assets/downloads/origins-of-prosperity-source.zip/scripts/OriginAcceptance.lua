-- 开发验收入口，正式游戏仍以 main.lua 为入口。
require("main")
local GameStart = Start
local UI = require("urhox-libs/UI")
local Tests = require("OriginTests")
local Simulation = require("OriginSimulation")
local acceptanceFrame = 0

local function Check(condition, message)
    assert(condition, "[验收失败] " .. message)
    print("[验收通过] " .. message)
end

local function ClickAt(x, y)
    local scale = UI.GetScale()
    local data = {pointerId = 0, pointerType = "mouse", button = MOUSEB_LEFT, x = x * scale, y = y * scale}
    UI.HandlePointerDown(UI.PointerEvent.new("PointerDown", data))
    UI.HandlePointerUp(UI.PointerEvent.new("PointerUp", data))
end

local function ClickWidget(ctx, id)
    local widget = assert(ctx.root:FindById(id), "控件不存在：" .. id)
    local l = widget:GetAbsoluteLayoutForHitTest()
    ClickAt(l.x + l.w / 2, l.y + l.h / 2)
end

function Start()
    GameStart()
    local intro = UI.GetTopOverlay() --[[@as Modal?]]
    if intro then intro:Close() end
    local testReport = Tests.Run()
    Check(testReport.ok, string.format("核心测试%d/%d通过", testReport.passed, testReport.total))
    local ctx = OriginDebug.GetGame()
    Check(#ctx.world.cells == 384, "世界包含384个地块")
    Check(ctx.world.generation == 0 and ctx.world.round == 0, "开局未赠送或消耗行动")
    OriginDebug.Select(24, 16)
    Check(ctx.selectedIndex == 384 and ctx.regionX == 22 and ctx.regionY == 14, "边缘选择保留完整3×3区域")
    OriginDebug.Select(12, 8)
    local before = ctx.world.cells[ctx.selectedIndex].craft
    OriginDebug.Choose("craft")
    ctx.tipsClosed = true
    OriginDebug.Confirm()
    Check(ctx.phase == "simulation" and ctx.ticksRemaining == 5, "确认后进入五世代演进")
    Check(math.abs(ctx.world.cells[ctx.selectedIndex].craft - before * 1.15) < 1e-10, "确认即时工艺改良")
    OriginDebug.Confirm()
    Check(ctx.world.round == 1, "演进期二次确认不赠送行动")
    ctx.paused = true
    OriginDebug.Advance()
    Check(ctx.world.generation == 0, "暂停不推进模拟")
    ctx.paused = false
    for _ = 1, 5 do OriginDebug.Advance() end
    Check(ctx.phase == "decision" and ctx.world.generation == 5, "五世代后返回决策期")
    Check(#ctx.world.history == 6, "历史包含初始与每世代数据")
    local replay = Simulation.Replay(ctx.seed, ctx.world.actions)
    Check(math.abs(replay.cells[1].population - ctx.world.cells[1].population) < 1e-10, "真实行动记录可确定性重放")
    OriginDebug.Choose("protect")
    OriginDebug.Confirm()
    Check(ctx.world.protectionLeft == 2, "保护行动消耗一次全局机会")
    Check(ctx.world.cells[ctx.selectedIndex].protectionTicks == 5, "保护即时覆盖五次竞争")
    for _ = 1, 5 do OriginDebug.Advance() end
    Check(ctx.world.cells[ctx.selectedIndex].protectionTicks == 0, "保护五次后恰好结束")
    OriginDebug.Restart()
    Check(ctx.world.generation == 0 and ctx.world.protectionLeft == 3, "同种子重开清空进度与保护次数")
    SubscribeToEvent("Update", "AcceptanceUpdate")
    print("[验收] 逻辑与交互接口检查完成，继续检查渲染与说明浮层。")
end

---@param eventType string
---@param eventData UpdateEventData
function AcceptanceUpdate(eventType, eventData)
    acceptanceFrame = acceptanceFrame + 1
    local ctx = OriginDebug.GetGame()
    if acceptanceFrame == 10 then
        UI.Layout()
        local map = ctx.root:FindById("worldMap") --[[@as OriginMap?]]
        Check(map ~= nil, "地图控件存在")
        if map then
            local b = map:Geometry()
            ClickAt(b.x + (7 - 0.5) * b.cw, b.y + (6 - 0.5) * b.ch)
            Check(ctx.selectedIndex == (6 - 1) * 24 + 7, "真实指针点击可选中地图格子")
        end
        ClickWidget(ctx, "layer_institution")
        Check(ctx.layer == "institution", "真实指针可切换制度图层")
        ClickWidget(ctx, "action_craft")
        Check(ctx.action == "craft", "真实指针可选择工艺行动")
        ClickWidget(ctx, "confirm")
        Check(ctx.phase == "simulation", "真实确认按钮可推进世代")
        ClickWidget(ctx, "play")
        Check(ctx.paused, "真实暂停按钮停止演进")
        local generation = ctx.world.generation
        OriginDebug.Advance()
        Check(ctx.world.generation == generation, "暂停观察不多赠世代")
        ClickWidget(ctx, "play")
        for _ = 1, 5 do OriginDebug.Advance() end
        Check(ctx.phase == "decision", "真实按钮行动后返回决策")
        OriginDebug.Restart()
    elseif acceptanceFrame == 20 then
        ctx.layer = "institution"
        OriginDebug.Select(5, 5)
    elseif acceptanceFrame == 30 then
        OriginDebug.Help()
        Check(ctx.modalOpen, "说明浮层打开")
    elseif acceptanceFrame == 45 then
        -- 模态关闭由真实按钮回调执行。
        local overlay = UI.GetTopOverlay() --[[@as Modal?]]
        if overlay then overlay:Close() end
    elseif acceptanceFrame == 55 then
        Check(not ctx.modalOpen, "说明浮层关闭并释放")
        for round = 1, 20 do
            OriginDebug.Select(2 + ((round - 1) % 7) * 3, 2 + (math.floor((round - 1) / 7) % 4) * 3)
            OriginDebug.Choose("craft")
            OriginDebug.Confirm()
            for _ = 1, 5 do if ctx.phase == "simulation" then OriginDebug.Advance() end end
            if ctx.world.won then break end
        end
        Check(ctx.phase == "ended", "完整游戏进入结算")
        Check(ctx.world.generation == 100 or ctx.world.won, "结算只在100世代或胜利时发生")
        Check(ctx.world.round <= 20 and #ctx.world.history == ctx.world.generation + 1, "结算行动与历史数量正确")
        Check(ctx.modalOpen, "真实事件结局浮层打开")
        local finalRound = ctx.world.round
        OriginDebug.Confirm()
        Check(ctx.world.round == finalRound, "结算后不能追加行动")
        print("[验收] 完整20轮、制度图层与真实事件结算已执行。")
    elseif acceptanceFrame == 125 then
        local overlay = UI.GetTopOverlay() --[[@as Modal?]]
        if overlay then overlay:Close() end
        Check(not ctx.modalOpen, "结算关闭后可继续检查地图")
    end
end
