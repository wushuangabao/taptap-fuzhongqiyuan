-- 基于官方 scaffold-2d.lua：Start → UI.Init → 数据 → 声明式界面 → Update。
local UI = require("urhox-libs/UI")
local Config = require("OriginConfig")
local Simulation = require("OriginSimulation")
local View = require("OriginView")

---@type table
local game = {
    world = {}, root = nil, baseline = {},
    seed = 20261002, phase = "decision", paused = false, speed = 1,
    layer = "quality", showMigration = true, action = "", ticksRemaining = 0,
    selectedIndex = 180, regionX = 11, regionY = 7, roundStart = 0,
    accumulator = 0, tickAge = 0, modalOpen = false, tipsClosed = false,
    seenMigration = false, seenCompetition = false, seenProsperity = false,
    viewportW = 0, viewportH = 0,
}

local function SelectCell(x, y)
    game.selectedIndex = (y - 1) * game.world.config.width + x
    -- 点击边缘仍检查真实地块；干预框移至地图内，不裁成不完整区域。
    local maxX = game.world.config.width - game.world.config.regionSize + 1
    local maxY = game.world.config.height - game.world.config.regionSize + 1
    game.regionX = math.max(1, math.min(maxX, x - 1))
    game.regionY = math.max(1, math.min(maxY, y - 1))
    View.Refresh(game)
end

local function Restart()
    game.world = Simulation.New(game.seed)
    game.phase = "decision"
    game.paused, game.action = false, ""
    game.ticksRemaining, game.accumulator, game.tickAge = 0, 0, 0
    game.seenMigration, game.seenCompetition, game.seenProsperity = false, false, false
    game.viewportW, game.viewportH = 0, 0
    game.selectedIndex = (8 - 1) * game.world.config.width + 12
    game.regionX, game.regionY = 11, 7
    View.Build(game)
    print(string.format("[重开] 种子%d 基准生活用品%.6f", game.seed, game.world.baselineCraft))
end

game.selectCell = SelectCell
game.restart = Restart

function Start()
    graphics.windowTitle = "富种起源 · 局部干预，观察涌现"
    input.mouseMode = MM_ABSOLUTE
    game.seed = Config.defaultSeed
    View.InitTheme()
    game.world = Simulation.New(game.seed)
    game.baseline = Simulation.Baseline(game.seed)
    game.selectedIndex = (8 - 1) * game.world.config.width + 12
    View.Build(game)
    SubscribeToEvent("Update", "HandleUpdate")
    SubscribeToEvent("KeyDown", "HandleKeyDown")
    print(string.format("[启动] 富种起源 规则%s 种子%d 地块%d", tostring(Config.modelVersion), game.seed, #game.world.cells))
    print(string.format("[基准] 开局人均生活用品%.6f，繁荣门槛%.6f", game.world.baselineCraft, 2 * game.world.baselineCraft))
    print("[模拟] 固定顺序同步结算，动画独立于模拟随机数。")
    View.Help(game)
end

function Stop()
    UnsubscribeFromAllEvents()
    UI.Shutdown()
end

local function AdvanceGeneration()
    local report = Simulation.Tick(game.world)
    game.ticksRemaining = game.ticksRemaining - 1
    game.tickAge = 0
    local summary = report.summary or Simulation.Statistics(game.world)
    print(string.format("[世代%d] 人口%.3f 生活用品%.5f 探索%.2f%% 繁荣%.2f%% 流量%d 替代%d",
        game.world.generation, summary.population, summary.craftPerCapita,
        summary.exploreShare * 100, summary.prosperousShare * 100, #report.flows, #report.changes))
    if game.world.won or game.world.generation >= game.world.config.rounds * game.world.config.generationsPerRound then
        game.phase, game.paused = "ended", false
        View.RoundReport(game)
        View.Ending(game)
    elseif game.ticksRemaining <= 0 then
        game.phase, game.paused = "decision", false
        View.RoundReport(game)
    end
    View.Refresh(game)
end

---@param eventType string
---@param eventData UpdateEventData
function HandleUpdate(eventType, eventData)
    local dt = math.min(0.25, eventData:GetFloat("TimeStep"))
    View.Resize(game)
    if not game.paused and not game.modalOpen then game.tickAge = game.tickAge + dt end
    if game.phase ~= "simulation" or game.paused or game.modalOpen then return end
    game.accumulator = game.accumulator + dt * game.speed
    local interval = 1.15
    -- 每次更新最多结算一个世代；帧率影响播放长度，不影响任何世代结果。
    if game.accumulator >= interval then
        game.accumulator = game.accumulator - interval
        AdvanceGeneration()
    end
end

---@param eventType string
---@param eventData KeyDownEventData
function HandleKeyDown(eventType, eventData)
    local key = eventData:GetInt("Key")
    if game.modalOpen then
        if key == KEY_ESCAPE then
            local overlay = UI.GetTopOverlay() --[[@as Modal?]]
            if overlay then overlay:Close() end
        end
        return
    end
    if key == KEY_SPACE and game.phase == "simulation" then
        game.paused = not game.paused
        View.Refresh(game)
    elseif key == KEY_ESCAPE and game.phase == "decision" then
        game.action = ""
        View.Refresh(game)
    elseif key == KEY_H then
        View.Help(game)
    end
end

-- 供引擎离屏自动验收访问同一数据与操作，正式玩法不依赖此入口。
OriginDebug = {
    GetGame = function() return game end,
    Select = SelectCell,
    Choose = function(action) game.action = action; View.Refresh(game) end,
    Confirm = function() View.Confirm(game) end,
    Advance = function()
        if game.phase == "simulation" and not game.paused then AdvanceGeneration() end
    end,
    Restart = Restart,
    Help = function() View.Help(game) end,
}
